-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 26 Jan 2023 pada 13.04
-- Versi server: 10.4.27-MariaDB
-- Versi PHP: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `toko`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `barang`
--

CREATE TABLE `barang` (
  `id_barang` varchar(10) NOT NULL,
  `nama_barang` varchar(100) NOT NULL,
  `jenis_barang` varchar(100) NOT NULL,
  `harga_beli` int(12) NOT NULL,
  `harga_jual` int(12) NOT NULL,
  `ukuran` varchar(10) NOT NULL,
  `stok` int(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `barang`
--

INSERT INTO `barang` (`id_barang`, `nama_barang`, `jenis_barang`, `harga_beli`, `harga_jual`, `ukuran`, `stok`) VALUES
('AN001', 'Hoodie', 'Jaket', 250000, 300000, 'L', 100),
('AN002', 'Chinos', 'Celana', 75000, 100000, 'L', 100),
('AN003', 'Oxford shirt ', 'Kemeja', 250000, 300000, 'L', 100),
('AN004', 'T-shirt / Kaos', 'Baju', 35000, 50000, 'L', 100),
('AN005', 'Jas', 'Jaket', 170000, 250000, 'L', 100),
('AN006', 'Kemeja Batik', 'Kemeja', 130000, 150000, 'L', 100);

-- --------------------------------------------------------

--
-- Struktur dari tabel `penjualan`
--

CREATE TABLE `penjualan` (
  `no_faktur` varchar(10) NOT NULL,
  `tanggal` varchar(20) NOT NULL,
  `total` int(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `penjualan`
--

INSERT INTO `penjualan` (`no_faktur`, `tanggal`, `total`) VALUES
('TR0001', '26-01-2023', 300000),
('TR0002', '26-01-2023', 300000),
('TR0003', '26-01-2023', 550000);

-- --------------------------------------------------------

--
-- Struktur dari tabel `penjualan_rinci`
--

CREATE TABLE `penjualan_rinci` (
  `id_penjualan_rinci` int(11) NOT NULL,
  `no_faktur` varchar(10) DEFAULT NULL,
  `id_barang` varchar(10) DEFAULT NULL,
  `nama_barang` varchar(100) DEFAULT NULL,
  `jumlah` int(12) DEFAULT NULL,
  `harga` int(12) DEFAULT NULL,
  `total` int(12) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `penjualan_rinci`
--

INSERT INTO `penjualan_rinci` (`id_penjualan_rinci`, `no_faktur`, `id_barang`, `nama_barang`, `jumlah`, `harga`, `total`) VALUES
(1, 'TR0002', 'AN001', 'Denim', 1, 300000, 300000),
(4, 'TR0003', 'AN004', 'T-shirt / Kaos', 5, 50000, 250000),
(5, 'TR0003', 'AN001', 'Hoodie', 1, 300000, 300000);

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `barang`
--
ALTER TABLE `barang`
  ADD PRIMARY KEY (`id_barang`);

--
-- Indeks untuk tabel `penjualan`
--
ALTER TABLE `penjualan`
  ADD PRIMARY KEY (`no_faktur`);

--
-- Indeks untuk tabel `penjualan_rinci`
--
ALTER TABLE `penjualan_rinci`
  ADD PRIMARY KEY (`id_penjualan_rinci`),
  ADD KEY `no_faktur` (`no_faktur`),
  ADD KEY `id_barang` (`id_barang`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `penjualan_rinci`
--
ALTER TABLE `penjualan_rinci`
  MODIFY `id_penjualan_rinci` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `penjualan_rinci`
--
ALTER TABLE `penjualan_rinci`
  ADD CONSTRAINT `penjualan_rinci_ibfk_1` FOREIGN KEY (`no_faktur`) REFERENCES `penjualan` (`no_faktur`),
  ADD CONSTRAINT `penjualan_rinci_ibfk_2` FOREIGN KEY (`id_barang`) REFERENCES `barang` (`id_barang`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
